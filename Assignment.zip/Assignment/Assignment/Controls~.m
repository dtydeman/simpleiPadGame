//
//  Controls.m
//  Assignment
//
//  Created by DANIEL TYDEMAN on 04/02/2014.
//  Copyright 2014 DANIEL TYDEMAN. All rights reserved.
//

#import "Controls.h"
#import "Level1.h"
#import "Level2.h"
#import "Level3.h"
#import "Player.h"

@interface Controls()
{
    Player *player;
    Level1 *level1;
    Level2 *level2;
    Level3 *level3;
}
@end

@implementation Controls

@synthesize leftButton = _leftButton;
@synthesize rightButton = _rightButton;
@synthesize jumpButton = _jumpButton;
@synthesize jumpLeftButton = _jumpLeftButton;
@synthesize jumpRightButton = _jumpRightButton;
@synthesize actionButton = _actionButton;
@synthesize emptyHandButton = _emptyHandButton;
@synthesize pickaxeItemButton = _pickaxeItemButton;
@synthesize scoreLabel = _scoreLabel;
@synthesize timeLabel = _timeLabel;
@synthesize scoreText = _scoreText;
@synthesize timeText = _timeText;

-(id) init
{
    //Create text strings for time and score
    self.scoreText = [CCLabelTTF labelWithString:[NSString stringWithFormat:@"Score: %i", player.score] fontName:@"Times New Roman" fontSize:25];
    self.timeText = [CCLabelTTF labelWithString: [NSString stringWithFormat:@"Time: %i", player.timeSeconds] fontName:@"Times New Roman" fontSize:25];
    
    //Create control buttons and labels
    self.leftButton = [CCMenuItemImage itemWithNormalImage:@"Left.png" selectedImage:@"LeftSel.png" target:self selector:@selector(leftButtonPressed:)];
    self.rightButton = [CCMenuItemImage itemWithNormalImage:@"Right.png" selectedImage:@"RightSel.png" target:self selector:@selector(rightButtonPressed:)];
    self.jumpButton = [CCMenuItemImage itemWithNormalImage:@"Jump.png" selectedImage:@"JumpSel.png" target:self selector:@selector(jumpButtonPressed:)];
    self.jumpLeftButton = [CCMenuItemImage itemWithNormalImage:@"Jump-Left.png" selectedImage:@"Jump-LeftSel.png" target:self selector:@selector(jumpLeftButtonPressed:)];
    self.jumpRightButton = [CCMenuItemImage itemWithNormalImage:@"Jump-Right.png" selectedImage:@"Jump-RightSel.png" target:self selector:@selector(jumpRightButtonPressed:)];
    self.actionButton = [CCMenuItemImage itemWithNormalImage:@"Action.png" selectedImage:@"ActionSel.png" target:self selector:@selector(actionButtonPressed:)];
    self.emptyHandButton = [CCMenuItemImage itemWithNormalImage:@"EmptyHand.png" selectedImage:@"EmptyHandSel.png" target:self selector:@selector(emptyButtonPressed:)];
    self.pickaxeItemButton = [CCMenuItemImage itemWithNormalImage:@"HaveItem.png" selectedImage:@"HaveItemSel.png" target:self selector:@selector(pickaxeButtonPressed:)];
    self.scoreLabel = [CCMenuItemLabel itemWithLabel:self.scoreText target:self selector:(nil)];
    self.timeLabel = [CCMenuItemLabel itemWithLabel:self.timeText target:self selector:(nil)];
    
    //Set the position of the control buttons  and labels
    self.leftButton.position = ccp(232,40);
    self.rightButton.position = ccp(300, 40);
    self.jumpButton.position = ccp(266, 74);
    self.jumpLeftButton.position = ccp(232, 74);
    self.jumpRightButton.position = ccp(300, 74);
    self.actionButton.position = ccp(266, 40);
    self.emptyHandButton.position = ccp(934, 50);
    self.pickaxeItemButton.position = ccp(900, 50);
    self.scoreLabel.position = ccp(720, 70);
    self.timeLabel.position = ccp(720, 40);
    
    //Set the initial accessibility of target button
    self.pickaxeItemButton.visible = NO;
    self.pickaxeItemButton.isEnabled = NO;
    
    //Add the buttons and labels to the control menu
    self.controlMenu = [CCMenu menuWithItems:self.rightButton, self.leftButton, self.jumpButton, self.jumpLeftButton, self.jumpRightButton, self.actionButton, self.emptyHandButton, self.pickaxeItemButton, self.scoreLabel, self.timeLabel, nil];
    
    //Set origin for group of controls
    self.controlMenu.position = CGPointZero;
    
    return self;
}

-(void)leftButtonPressed:(id)sender
{
    //Set boolean values
    player.moveRight = NO;
    player.moveLeft = YES;
    player.jumpUp = NO;
    player.jumpToRight = NO;
    player.jumpToLeft = NO;
    player.faceRight = NO;
    player.faceLeft = YES;
    
    //Change the player sprite to the correct direction and with or without pickaxe
    if (player.havePickaxe)
    {
        if (player.faceRight)
        {
            
        }
        else if (player.faceLeft)
        {
            [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-left-pickaxe.png"]];
        }
    }
    else if (!player.havePickaxe)
    {
        if (player.faceRight)
        {
            
        }
        else if (player.faceLeft)
        {
            [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-left.png"]];
        }
    }
}

-(void)rightButtonPressed:(id)sender
{
    //Set boolean values
    player.moveRight = YES;
    player.moveLeft = NO;
    player.jumpUp = NO;
    player.jumpToRight = NO;
    player.jumpToLeft = NO;
    player.faceRight = YES;
    player.faceLeft = NO;
    
    //Change the player sprite to the correct direction and with or without pickaxe
    if (player.havePickaxe)
    {
        if (player.faceRight)
        {
            [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-right-pickaxe.png"]];
        }
        else if (player.faceLeft)
        {
            
        }
    }
    else if (!player.havePickaxe)
    {
        if (player.faceRight)
        {
            [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-right.png"]];
        }
        else if (player.faceLeft)
        {
            
        }
    }
}

-(void)jumpButtonPressed:(id)sender
{
    //Set boolean values
    player.moveRight = NO;
    player.moveLeft = NO;
    player.jumpUp = YES;
    player.jumpToRight = NO;
    player.jumpToLeft = NO;
    
}

-(void)jumpLeftButtonPressed:(id)sender
{
    //Set boolean values
    player.moveRight = NO;
    player.moveLeft = NO;
    player.jumpUp = NO;
    player.jumpToRight = NO;
    player.jumpToLeft = YES;
    player.faceRight = NO;
    player.faceLeft = YES;
    
    //Change the player sprite to the correct direction and with or without pickaxe
    if (player.havePickaxe)
    {
        if (player.faceRight)
        {
            
        }
        else if (player.faceLeft)
        {
            [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-left-pickaxe.png"]];
        }
    }
    else if (!player.havePickaxe)
    {
        if (player.faceRight)
        {
            
        }
        else if (player.faceLeft)
        {
            [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-left.png"]];
        }
    }
}

-(void)jumpRightButtonPressed:(id)sender
{
    //Set boolean values
    player.moveRight = NO;
    player.moveLeft = NO;
    player.jumpUp = NO;
    player.jumpToRight = YES;
    player.jumpToLeft = NO;
    player.faceRight = YES;
    player.faceLeft = NO;
    
    //Change the player sprite to the correct direction and with or without pickaxe
    if (player.havePickaxe)
    {
        if (player.faceRight)
        {
            [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-right-pickaxe.png"]];
        }
        else if (player.faceLeft)
        {
            
        }
    }
    else if (!player.havePickaxe)
    {
        if (player.faceRight)
        {
            [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-right.png"]];
        }
        else if (player.faceLeft)
        {
            
        }
    }
}

-(void)actionButtonPressed:(id)sender
{
    //Set boolean values dependant on having pickaxe selected
    if(player.havePickaxe)
    {
        player.moveRight = NO;
        player.moveLeft = NO;
        player.jumpUp = NO;
        player.jumpToRight = NO;
        player.jumpToLeft = NO;
        player.smash = YES;
    }
    //If player does not have the pickaxe selected
    else
    {
        player.moveRight = NO;
        player.moveLeft = NO;
        player.jumpUp = NO;
        player.jumpToRight = NO;
        player.jumpToLeft = NO;
        player.smash = NO;
    }
}

-(void)pickaxeButtonPressed:(id)sender
{
    //Set boolean value
    player.havePickaxe = YES;
    //Change player sprite to include pickaxe
    if (player.faceLeft)
    {
        [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-left-pickaxe.png"]];
    }
    else if (player.faceRight)
    {
        [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-right-pickaxe.png"]];
    }
}

-(void)emptyButtonPressed:(id)sender
{
    //Set boolean value
    player.havePickaxe = NO;
    
    //Change player sprite to remove pickaxe
    if (player.faceLeft)
    {
        [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-left.png"]];
    }
    else if (player.faceRight)
    {
        [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-right.png"]];
    }
}

@end
