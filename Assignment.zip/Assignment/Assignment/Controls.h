//
//  Controls.h
//  Assignment
//
//  Created by DANIEL TYDEMAN on 04/02/2014.
//  Copyright 2014 DANIEL TYDEMAN. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface Controls : CCLayer {
    
}

@property (nonatomic, assign) CCMenuItem *leftButton;
@property (nonatomic, assign) CCMenuItem *rightButton;
@property (nonatomic, assign) CCMenuItem *jumpButton;
@property (nonatomic, assign) CCMenuItem *jumpLeftButton;
@property (nonatomic, assign) CCMenuItem *jumpRightButton;
@property (nonatomic, assign) CCMenuItem *actionButton;
@property (nonatomic, assign) CCMenuItem *emptyHandButton;
@property (nonatomic, assign) CCMenuItem *pickaxeItemButton;

@property (nonatomic, assign) CCLabelTTF *timeLabel;
@property (nonatomic, assign) CCLabelTTF *scoreLabel;
@property (nonatomic, assign) CCLabelTTF *timeText;
@property (nonatomic, assign) CCLabelTTF *scoreText;

@property (nonatomic, assign) CCMenu *controlMenu;


@end
