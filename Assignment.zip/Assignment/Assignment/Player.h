//
//  Player.h
//  Assignment
//
//  Created by DANIEL TYDEMAN on 24/01/2014.
//  Copyright 2014 DANIEL TYDEMAN. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface Player : CCSprite 
    
@property (nonatomic, assign) CGPoint velocity;
@property (nonatomic, assign) CGPoint desiredPosition;

@property (nonatomic, assign) BOOL faceRight;
@property (nonatomic, assign) BOOL faceLeft;
@property (nonatomic, assign) BOOL moveRight;
@property (nonatomic, assign) BOOL moveLeft;
@property (nonatomic, assign) BOOL jumpUp;
@property (nonatomic, assign) BOOL jumpToRight;
@property (nonatomic, assign) BOOL jumpToLeft;
@property (nonatomic, assign) BOOL onGround;
@property (nonatomic, assign) BOOL havePickaxe;
@property (nonatomic, assign) BOOL boulderHere;
@property (nonatomic, assign) BOOL smash;
@property (nonatomic, assign) BOOL breakLeft;
@property (nonatomic, assign) BOOL breakRight;

@property (nonatomic, assign) int score;
@property (nonatomic, assign) int time;
@property (nonatomic, assign) int timeSeconds;

-(void)update:(ccTime)dt;
-(CGRect)collisionDetect;



@end
