//
//  Level2.h
//  Assignment
//
//  Created by DANIEL TYDEMAN on 04/02/2014.
//  Copyright 2014 DANIEL TYDEMAN. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface Level2 : CCLayer {
    
}

@property (nonatomic, assign) CCLabelTTF *timeLabel;
@property (nonatomic, assign) CCLabelTTF *scoreLabel;
@property (nonatomic, assign) CCLabelTTF *timeText;
@property (nonatomic, assign) CCLabelTTF *scoreText;

+(CCScene *) scene2;

@end
