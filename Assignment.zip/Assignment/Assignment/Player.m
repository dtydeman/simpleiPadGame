//
//  Player.m
//  Assignment
//
//  Created by DANIEL TYDEMAN on 24/01/2014.
//  Copyright 2014 DANIEL TYDEMAN. All rights reserved.
//

#import "Player.h"

@interface Player()
{

}
@end

@implementation Player

@synthesize velocity = _velocity;
@synthesize desiredPosition = _desiredPosition;
@synthesize faceLeft = _faceLeft;
@synthesize faceRight = _faceRight;
@synthesize moveRight = _moveRight;
@synthesize moveLeft = _moveLeft;
@synthesize jumpUp = _jumpUp;
@synthesize jumpToRight = _jumpToRight;
@synthesize jumpToLeft = _jumpToLeft;
@synthesize onGround = _onGround;
@synthesize havePickaxe = _havePickaxe;
@synthesize boulderHere = _boulderHere;
@synthesize smash = _smash;
@synthesize breakLeft = _breakLeft;
@synthesize breakRight = _breakRight;
@synthesize score = _score;
@synthesize time = _time;
@synthesize timeSeconds = _timeSeconds;

-(id)initWithFile:(NSString *)filename {
    if (self = [super initWithFile:filename]) {
        //Init goes here
        self.velocity = ccp(0.0, 0.0);
        self.havePickaxe = NO;
    }
    return self;
}

-(void)update:(ccTime)dt
{
    //Declare gravity vector
	CGPoint gravity = ccp(0.0, -450.0);
	//Calculate gravity for current time step
    CGPoint gravityStep = ccpMult(gravity, dt);
    //Set movement forces
    CGPoint walkRight = ccp(800.0, 0.0);
    CGPoint walkLeft = ccp(-800.0, 0.0);
    CGPoint jumpStraight = ccp(0.0, 5000.0);
    CGPoint jumpRight = ccp(800.0, 5000.0);
    CGPoint jumpLeft = ccp(-800.0, 5000.0);
    
    //Set consistent acceleration
    CGPoint rightStep = ccpMult(walkRight, dt);
    CGPoint leftStep = ccpMult(walkLeft, dt);
    CGPoint jumpStraightStep = ccpMult(jumpStraight, dt);
    CGPoint jumpRightStep = ccpMult(jumpRight, dt);
    CGPoint jumpLeftStep = ccpMult(jumpLeft, dt);

	//Add gravity to velocity for current time step
    self.velocity= ccpAdd(self.velocity, gravityStep);
    //Simulate friction with a low-level damping force
    self.velocity = ccp(self.velocity.x *0.90, self.velocity.y);
    
    if(self.moveRight)
    {
        //Move right if button is pressed
        self.velocity = ccpAdd(self.velocity, rightStep);
    }
    else if (self.moveLeft)
    {
        //Move left if button is pressed
        self.velocity = ccpAdd(self.velocity, leftStep);
    }
    else if (self.jumpUp && self.onGround)
    {
        //Move vertically up if button is pressed
        self.velocity = ccpAdd(self.velocity, jumpStraightStep);
    }
    else if (self.jumpToRight && self.onGround)
    {
        //Move vertically up if button is pressed
        self.velocity = ccpAdd(self.velocity, jumpRightStep);
    }
    else if (self.jumpToLeft && self.onGround)
    {
        //Move vertically up if button is pressed
        self.velocity = ccpAdd(self.velocity, jumpLeftStep);
    }
    
    //Limit max falling speed
    CGPoint minMovement = ccp(-70.0, -450.0);
    //Limit max jumping/running speed
    CGPoint maxMovement = ccp(70.0, 170.0);
    self.velocity = ccpClamp(self.velocity, minMovement, maxMovement);
    //Calculate consistent velocity
    CGPoint stepVelocity = ccpMult(self.velocity, dt);
	//Get updated position of player
    self.desiredPosition = ccpAdd(self.position, stepVelocity);
    
    //Prevent jumps from looping
    self.jumpUp = NO;
    self.jumpToRight = NO;
    self.jumpToLeft = NO;
}

-(CGRect)collisionDetect
{
    //Create a collision detection box around the player
    CGRect collisionBox = CGRectInset(self.boundingBox, 0, 0);
    //Set the difference between the player's current position and the new, desired position
    CGPoint diff = ccpSub(self.desiredPosition, self.position);
    //Check if the collision detection has intersected with anything
    CGRect returnBoundingBox = CGRectOffset(collisionBox, diff.x, diff.y);
    //Return if the collision detection has intersected with anything
    return returnBoundingBox;
}

@end
