//
//  Collisions.m
//  Assignment
//
//  Created by DANIEL TYDEMAN on 04/02/2014.
//  Copyright 2014 DANIEL TYDEMAN. All rights reserved.
//

#import "Collisions.h"
#import "Player.h"
#import "Level1.h"
#import "Level2.h"
#import "Level3.h"

@interface Collisions()
{
    CCTMXTiledMap *map1;
    CCTMXTiledMap *map2;
    CCTMXTiledMap *map3;
    CCTMXLayer *collisions;
    CCTMXLayer *boulder;
    
    Player *player;
    Level1 *level1;
    Level2 *level2;
    Level3 *level3;
}
@end

@implementation Collisions

-(CGPoint)tileCoordOfPlayer:(CGPoint)position
{
    //Locates X value of currently occupied tile
    float x = floor(position.x / map1.tileSize.width);
    //Calculates the size of the level to help determine Y coordinate
    float levelHeight = map1.mapSize.height * map1.tileSize.height;
    //Locates the Y value of currently occupied tile by inverting the height
    float y = floor((levelHeight - position.y) / map1.tileSize.height);
    //Returns the coordinates of the player
    return ccp(x, y);
}

-(CGRect)tileRectOfPlayer:(CGPoint)tileCoords
{
    //Recalculates the size of the level
    float levelHeight = map1.mapSize.height * map1.tileSize.height;
    //Calculates the tile the player is occupying
    CGPoint origin = ccp(tileCoords.x * map1.tileSize.width, levelHeight - ((tileCoords.y + 1)
                                                                            * map1.tileSize.height));
    //Returns the tile the player is located in
    return CGRectMake(origin.x, origin.y, map1.tileSize.width, map1.tileSize.height);
}

-(NSArray *)getSurroundingTiles:(CGPoint)position forLayer:(CCTMXLayer *)layer
{
    //Call the current player position
    CGPoint playerPosition = [self tileCoordOfPlayer:position];
    
    //Array to hold adjacent tile information
    NSMutableArray *gridIDs = [NSMutableArray array];
    
    //Loop to check all tiles around player, and tile the player is occupying as well
    for (int i = 0; i < 9; i++)
    {
        int c = i % 3;
        int r = (int)(i /3);
        CGPoint tilePosition = ccp(playerPosition.x + (c - 1), playerPosition.y + (r - 1));
        
        //Returns the tile's global identifier to help determine tiles found
        int tileGridID = [layer tileGIDAt:tilePosition];
        
        //Set a rectangle at the player position to hep catalogue tile locations
        CGRect tileRect = [self tileRectOfPlayer:tilePosition];
        
        //Create a dictionary for each tile's coordinates in the level
        NSDictionary *tileDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                        [NSNumber numberWithInt:tileGridID], @"tileGridID",
                                        [NSNumber numberWithFloat:tileRect.origin.x], @"x",
                                        [NSNumber numberWithFloat:tileRect.origin.y], @"y",
                                        [NSValue valueWithCGPoint:tilePosition], @"tilePosition",
                                        nil];
        //Add the dictionaries to the array
        [gridIDs addObject:tileDictionary];
    }
    
    //Reorder tiles by priority; focusing on tiles directly above/below and infront/behind
    [gridIDs removeObjectAtIndex:4];
    [gridIDs insertObject:[gridIDs objectAtIndex:2] atIndex:6];
    [gridIDs removeObjectAtIndex:2];
    [gridIDs exchangeObjectAtIndex:4 withObjectAtIndex:6];
    [gridIDs exchangeObjectAtIndex:0 withObjectAtIndex:4];
    
    return (NSArray *)gridIDs;
}

-(void)checkForAndResolveCollisions:(Player *)p
{
    //Retrieve set of tiles around player and identify collisions
    NSArray *tiles = [self getSurroundingTiles:p.position forLayer:collisions];
    
    //State that the player is not on the ground
    p.onGround = NO;
    
    //Loop to check if there is a collision for each new, desired position
    for (NSDictionary *dictionary in tiles)
    {
        //Get the current collision detection box for the player
        CGRect pRectangle = [p collisionDetect];
        
        //Retrieve ID for tile from dictionary
        int gridID = [[dictionary objectForKey:@"tileGridID"] intValue];
        
        if (gridID)
        {
            //If there is a tile in the identified space, create a CGRect to check for collisions
            //If no identified tile, then step is ignored
            CGRect tileRect = CGRectMake([[dictionary objectForKey:@"x"] floatValue], [[dictionary objectForKey:@"y"] floatValue], map1.tileSize.width, map1.tileSize.height);
            //Check for collisions by seeing if the player collision rectangle intersects with any
            //of the tile rectangles
            if (CGRectIntersectsRect(pRectangle, tileRect))
            {
                CGRect intersection = CGRectIntersection(pRectangle, tileRect);
                
                //Use an index to determine the position of the current tile
                int tileIndex = [tiles indexOfObject:dictionary];
                
                if(tileIndex == 0)
                {
                    //Tile is directly below player
                    p.desiredPosition = ccp(p.desiredPosition.x, p.desiredPosition.y + intersection.size.height);
                    //Set the player's velocity back to 0, to prevent falling through the ground
                    p.velocity = ccp(p.velocity.x, 0.0);
                    //State that the player is on the ground
                    p.onGround = YES;
                }
                else if (tileIndex == 1)
                {
                    //Tile is directly above player
                    p.desiredPosition = ccp(p.desiredPosition.x, p.desiredPosition.y - intersection.size.height);
                    p.velocity = ccp(p.velocity.x, 0.0);
                }
                else if (tileIndex == 2)
                {
                    //Tile is to the left of the player
                    p.desiredPosition = ccp(p.desiredPosition.x + intersection.size.width, p.desiredPosition.y);
                    p.boulderHere = YES;
                }
                else if (tileIndex == 3)
                {
                    //Tile is to the right of the player
                    p.desiredPosition = ccp(p.desiredPosition.x - intersection.size.width, p.desiredPosition.y);
                    p.boulderHere = YES;
                }
                else
                {
                    if (intersection.size.width > intersection.size.height)
                    {
                        
                        //Set the player's velocity back to 0, to prevent falling through the ground
                        p.velocity = ccp(p.velocity.x, 0.0);
                        //Tile is diagonal, but resolving collision vertically
                        float resolutionHeight;
                        if (tileIndex > 5)
                        {
                            resolutionHeight = intersection.size.height;
                            //State that the player is on the ground
                            p.onGround = YES;
                        }
                        else
                        {
                            resolutionHeight = -intersection.size.height;
                        }
                        p.desiredPosition = ccp(p.desiredPosition.x, p.desiredPosition.y + resolutionHeight);
                        
                    }
                    else
                    {
                        //Tile is diagonal, but resolving collision as if horizontal
                        float resolutionWidth;
                        if (tileIndex == 6 || tileIndex == 4)
                        {
                            resolutionWidth = intersection.size.width;
                        }
                        else
                        {
                            resolutionWidth = -intersection.size.width;
                        }
                        p.desiredPosition = ccp(p.desiredPosition.x , p.desiredPosition.y + resolutionWidth);
                    }
                }
                
            }
        }
    }
    //After dealing with any relevant collisions, move the player to new position
    p.position = p.desiredPosition;
}

-(void)checkForBoulders:(Player *)p
{
    //Retrieve set of tiles around player and identify collisions
    NSArray *boulderTiles = [self getSurroundingTiles:p.position forLayer:boulder];
    
    //Loop to check if there is a collision for each new, desired position
    for (NSDictionary *dictionary in boulderTiles)
    {
        //Get the current collision detection box for the player
        CGRect pRectangle = [p collisionDetect];
        
        //Retrieve ID for tile from dictionary
        int gridID = [[dictionary objectForKey:@"tileGridID"] intValue];
        
        if (gridID)
        {
            //If there is a tile in the identified space, create a CGRect to check for collisions
            //If no identified tile, then step is ignored
            CGRect tileRect = CGRectMake([[dictionary objectForKey:@"x"] floatValue], [[dictionary objectForKey:@"y"] floatValue], map1.tileSize.width, map1.tileSize.height);
            //Check for collisions by seeing if the player collision rectangle intersects with any
            //of the tile rectangles
            if (CGRectIntersectsRect(pRectangle, tileRect))
            {
                CGRect intersection = CGRectIntersection(pRectangle, tileRect);
                
                //Use an index to determine the position of the current tile
                int tileIndex = [boulderTiles indexOfObject:dictionary];
                
                if(tileIndex == 0)
                {
                    //Tile is directly below player
                    p.desiredPosition = ccp(p.desiredPosition.x, p.desiredPosition.y + intersection.size.height);
                    //Set the player's vertical velocity back to 0, to prevent falling through the ground
                    p.velocity = ccp(p.velocity.x, 0.0);
                    //State that the player is on the ground
                    p.onGround = YES;
                }
                else if (tileIndex == 1)
                {
                    //Tile is directly above player
                    p.desiredPosition = ccp(p.desiredPosition.x, p.desiredPosition.y - intersection.size.height);
                    p.velocity = ccp(p.velocity.x, 0.0);
                }
                else if (tileIndex == 2)
                {
                    //Tile is to the left of the player
                    p.desiredPosition = ccp(p.desiredPosition.x + intersection.size.width, p.desiredPosition.y);
                    p.boulderHere = YES;
                }
                else if (tileIndex == 3)
                {
                    //Tile is to the right of the player
                    p.desiredPosition = ccp(p.desiredPosition.x - intersection.size.width, p.desiredPosition.y);
                    p.boulderHere = YES;
                }
                else
                {
                    if (intersection.size.width > intersection.size.height)
                    {
                        
                        //Set the player's velocity back to 0, to prevent falling through the ground
                        p.velocity = ccp(p.velocity.x, 0.0);
                        //Tile is diagonal, but resolving collision vertically
                        float resolutionHeight;
                        if (tileIndex > 5)
                        {
                            resolutionHeight = intersection.size.height;
                            //State that the player is on the ground
                            p.onGround = YES;
                        }
                        else
                        {
                            resolutionHeight = -intersection.size.height;
                        }
                        p.desiredPosition = ccp(p.desiredPosition.x, p.desiredPosition.y + resolutionHeight);
                        
                    }
                    else
                    {
                        //Tile is diagonal, but resolving collision as if horizontal
                        float resolutionWidth;
                        if (tileIndex == 6 || tileIndex == 4)
                        {
                            resolutionWidth = intersection.size.width;
                        }
                        else
                        {
                            resolutionWidth = -intersection.size.width;
                        }
                        p.desiredPosition = ccp(p.desiredPosition.x , p.desiredPosition.y + resolutionWidth);
                    }
                }
                
            }
        }
    }
    //After dealing with any relevant collisions, move the player to new position
    p.position = p.desiredPosition;
}

@end
