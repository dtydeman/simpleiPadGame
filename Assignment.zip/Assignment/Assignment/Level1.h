//
//  Level1.h
//  Assignment
//
//  Created by DANIEL TYDEMAN on 24/01/2014.
//  Copyright 2014 DANIEL TYDEMAN. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface Level1 : CCLayer
{

}

@property (nonatomic, assign) CCMenuItem *pickaxeItemButton;
@property (nonatomic, assign) CCLabelTTF *timeLabel;
@property (nonatomic, assign) CCLabelTTF *scoreLabel;
@property (nonatomic, assign) CCLabelTTF *timeText;
@property (nonatomic, assign) CCLabelTTF *scoreText;

+(CCScene *) scene;

@end
