//
//  Level3.m
//  Assignment
//
//  Created by DANIEL TYDEMAN on 04/02/2014.
//  Copyright 2014 DANIEL TYDEMAN. All rights reserved.
//

#import "Level3.h"
#include "SimpleAudioEngine.h"
#import"Player.h"
#import "Level2.h"

@interface Level3()
{
    CCTMXTiledMap *map3;
    CCTMXLayer *collisions;
    CCTMXLayer *boulder;
    CCTMXLayer *end;
    Player *player;
}
@end


@implementation Level3

+(CCScene *) scene3
{
	// 'scene' is an autorelease object.
	CCScene *scene3 = [CCScene node];
	
	// 'layer' is an autorelease object.
	Level2 *layer3 = [Level2 node];
	
	// add layer as a child to scene
	[scene3 addChild: layer3];
	
	// return the scene
	return scene3;
}

-(id) init
{
	if( (self=[super init]) ) {
        //init goes here
        //Add map
        map3 = [[CCTMXTiledMap alloc] initWithTMXFile:@"level-3.tmx"];
        //Add the level map to the scene
        [self addChild:map3];
        //Check the various layers of the TMX map
        collisions = [map3 layerNamed:@"collisions"];
        boulder = [map3 layerNamed:@"rocks"];
        end = [map3 layerNamed:@"end"];
        
        //Allocate Player
        player = [[Player alloc] initWithFile:@"player-right.png"];
        //Set player starting position
        player.position = ccp(35,710);
        //Add player to the scene
        [map3 addChild:player z:100];
        
        //Create text strings for time and score
		self.scoreText = [CCLabelTTF labelWithString:[NSString stringWithFormat:@"Score: %i", player.score] fontName:@"Times New Roman" fontSize:25];
		self.timeText = [CCLabelTTF labelWithString: [NSString stringWithFormat:@"Time: %i", player.timeSeconds] fontName:@"Times New Roman" fontSize:25];
		
		//Create control buttons and labels
        CCMenuItem *leftButton = [CCMenuItemImage itemWithNormalImage:@"Left.png" selectedImage:@"LeftSel.png" target:self selector:@selector(leftButtonPressed:)];
        CCMenuItem *rightButton = [CCMenuItemImage itemWithNormalImage:@"Right.png" selectedImage:@"RightSel.png" target:self selector:@selector(rightButtonPressed:)];
        CCMenuItem *jumpButton = [CCMenuItemImage itemWithNormalImage:@"Jump.png" selectedImage:@"JumpSel.png" target:self selector:@selector(jumpButtonPressed:)];
        CCMenuItem *jumpLeftButton = [CCMenuItemImage itemWithNormalImage:@"Jump-Left.png" selectedImage:@"Jump-LeftSel.png" target:self selector:@selector(jumpLeftButtonPressed:)];
        CCMenuItem *jumpRightButton = [CCMenuItemImage itemWithNormalImage:@"Jump-Right.png" selectedImage:@"Jump-RightSel.png" target:self selector:@selector(jumpRightButtonPressed:)];
        CCMenuItem *actionButton = [CCMenuItemImage itemWithNormalImage:@"Action.png" selectedImage:@"ActionSel.png" target:self selector:@selector(actionButtonPressed:)];
        CCMenuItem *emptyHandButton = [CCMenuItemImage itemWithNormalImage:@"EmptyHand.png" selectedImage:@"EmptyHandSel.png" target:self selector:@selector(emptyButtonPressed:)];
        CCMenuItem *pickaxeItemButton = [CCMenuItemImage itemWithNormalImage:@"HaveItem.png" selectedImage:@"HaveItemSel.png" target:self selector:@selector(pickaxeButtonPressed:)];
        self.scoreLabel = [CCMenuItemLabel itemWithLabel:self.scoreText target:self selector:(nil)];
        self.timeLabel = [CCMenuItemLabel itemWithLabel:self.timeText target:self selector:(nil)];
		
        //Set the position of the control buttons  and labels
        leftButton.position = ccp(232,40);
        rightButton.position = ccp(300, 40);
        jumpButton.position = ccp(266, 74);
        jumpLeftButton.position = ccp(232, 74);
        jumpRightButton.position = ccp(300, 74);
        actionButton.position = ccp(266, 40);
        emptyHandButton.position = ccp(934, 40);
        pickaxeItemButton.position = ccp(900, 40);
		self.scoreLabel.position = ccp(720, 70);
        self.timeLabel.position = ccp(720, 40);
        
        //Add the buttons and labels to the control menu
        CCMenu *controlMenu = [CCMenu menuWithItems:rightButton, leftButton, jumpButton, jumpLeftButton, jumpRightButton, actionButton, emptyHandButton, pickaxeItemButton, self.scoreLabel, self.timeLabel, nil];
        
        //Set origin for group of controls
        controlMenu.position = CGPointZero;
        //Add controls to scene
        [self addChild:controlMenu z:100];
        
        //Run update loop
        [self schedule:@selector(update:)];
	}
	return self;
}

-(void)update:(ccTime)dt
{
    //Call the update method from the player class
    [player update:dt];
    //Update time and score
    [self scoreAndTime:dt];
    //Call check for collisions
    [self checkForAndResolveCollisions:player];
    //Call check for boulders
    [self checkForBoulders:player];
	//Call method for mevoing boulders
    [self boulders];
	//Call method for moving to next level
    [self endLevel];
    
    //Prevent jumps from looping
    player.jumpUp = NO;
    player.jumpToRight = NO;
    player.jumpToLeft = NO;
    
    
}

-(CGPoint)tileCoordOfPlayer:(CGPoint)position
{
    //Locates X value of currently occupied tile
    float x = floor(position.x / map3.tileSize.width);
    //Calculates the size of the level to help determine Y coordinate
    float levelHeight = map3.mapSize.height * map3.tileSize.height;
    //Locates the Y value of currently occupied tile by inverting the height
    float y = floor((levelHeight - position.y) / map3.tileSize.height);
    //Returns the coordinates of the player
    return ccp(x, y);
}

-(CGRect)tileRectOfPlayer:(CGPoint)tileCoords
{
    //Recalculates the size of the level
    float levelHeight = map3.mapSize.height * map3.tileSize.height;
    //Calculates the tile the player is occupying
    CGPoint origin = ccp(tileCoords.x * map3.tileSize.width, levelHeight - ((tileCoords.y + 1)
                                                                            * map3.tileSize.height));
    //Returns the tile the player is located in
    return CGRectMake(origin.x, origin.y, map3.tileSize.width, map3.tileSize.height);
}

-(NSArray *)getSurroundingTiles:(CGPoint)position forLayer:(CCTMXLayer *)layer
{
    //Call the current player position
    CGPoint playerPosition = [self tileCoordOfPlayer:position];
    
    //Array to hold adjacent tile information
    NSMutableArray *gridIDs = [NSMutableArray array];
    
    //Loop to check all tiles around player, and tile the player is occupying as well
    for (int i = 0; i < 9; i++)
    {
        int c = i % 3;
        int r = (int)(i /3);
        CGPoint tilePosition = ccp(playerPosition.x + (c - 1), playerPosition.y + (r - 1));
        
        //Returns the tile's global identifier to help determine tiles found
        int tileGridID = [layer tileGIDAt:tilePosition];
        
        //Set a rectangle at the player position to hep catalogue tile locations
        CGRect tileRect = [self tileRectOfPlayer:tilePosition];
        
        //Create a dictionary for each tile's coordinates in the level
        NSDictionary *tileDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                        [NSNumber numberWithInt:tileGridID], @"tileGridID",
                                        [NSNumber numberWithFloat:tileRect.origin.x], @"x",
                                        [NSNumber numberWithFloat:tileRect.origin.y], @"y",
                                        [NSValue valueWithCGPoint:tilePosition], @"tilePosition",
                                        nil];
        //Add the dictionaries to the array
        [gridIDs addObject:tileDictionary];
    }
    
    //Reorder tiles by priority; focusing on tiles directly above/below and infront/behind
    [gridIDs removeObjectAtIndex:4];
    [gridIDs insertObject:[gridIDs objectAtIndex:2] atIndex:6];
    [gridIDs removeObjectAtIndex:2];
    [gridIDs exchangeObjectAtIndex:4 withObjectAtIndex:6];
    [gridIDs exchangeObjectAtIndex:0 withObjectAtIndex:4];
    
    return (NSArray *)gridIDs;
}

-(void)checkForAndResolveCollisions:(Player *)p
{
    //Retrieve set of tiles around player and identify collisions
    NSArray *tiles = [self getSurroundingTiles:p.position forLayer:collisions];
    
    //State that the player is not on the ground
    p.onGround = NO;
    
    //Loop to check if there is a collision for each new, desired position
    for (NSDictionary *dictionary in tiles)
    {
        //Get the current collision detection box for the player
        CGRect pRectangle = [p collisionDetect];
        
        //Retrieve ID for tile from dictionary
        int gridID = [[dictionary objectForKey:@"tileGridID"] intValue];
        
        if (gridID)
        {
            //If there is a tile in the identified space, create a CGRect to check for collisions
            //If no identified tile, then step is ignored
            CGRect tileRect = CGRectMake([[dictionary objectForKey:@"x"] floatValue], [[dictionary objectForKey:@"y"] floatValue], map3.tileSize.width, map3.tileSize.height);
            //Check for collisions by seeing if the player collision rectangle intersects with any
            //of the tile rectangles
            if (CGRectIntersectsRect(pRectangle, tileRect))
            {
                CGRect intersection = CGRectIntersection(pRectangle, tileRect);
                
                //Use an index to determine the position of the current tile
                int tileIndex = [tiles indexOfObject:dictionary];
                
                if(tileIndex == 0)
                {
                    //Tile is directly below player
                    p.desiredPosition = ccp(p.desiredPosition.x, p.desiredPosition.y + intersection.size.height);
                    //Set the player's velocity back to 0, to prevent falling through the ground
                    p.velocity = ccp(p.velocity.x, 0.0);
                    //State that the player is on the ground
                    p.onGround = YES;
                }
                else if (tileIndex == 1)
                {
                    //Tile is directly above player
                    p.desiredPosition = ccp(p.desiredPosition.x, p.desiredPosition.y - intersection.size.height);
                    p.velocity = ccp(p.velocity.x, 0.0);
                }
                else if (tileIndex == 2)
                {
                    //Tile is to the left of the player
                    p.desiredPosition = ccp(p.desiredPosition.x + intersection.size.width, p.desiredPosition.y);
                    p.boulderHere = YES;
                }
                else if (tileIndex == 3)
                {
                    //Tile is to the right of the player
                    p.desiredPosition = ccp(p.desiredPosition.x - intersection.size.width, p.desiredPosition.y);
                    p.boulderHere = YES;
                }
                else
                {
                    if (intersection.size.width > intersection.size.height)
                    {
                        
                        //Set the player's velocity back to 0, to prevent falling through the ground
                        p.velocity = ccp(p.velocity.x, 0.0);
                        //Tile is diagonal, but resolving collision vertically
                        float resolutionHeight;
                        if (tileIndex > 5)
                        {
                            resolutionHeight = intersection.size.height;
                            //State that the player is on the ground
                            p.onGround = YES;
                        }
                        else
                        {
                            resolutionHeight = -intersection.size.height;
                        }
                        p.desiredPosition = ccp(p.desiredPosition.x, p.desiredPosition.y + resolutionHeight);
                        
                    }
                    else
                    {
                        //Tile is diagonal, but resolving collision as if horizontal
                        float resolutionWidth;
                        if (tileIndex == 6 || tileIndex == 4)
                        {
                            resolutionWidth = intersection.size.width;
                        }
                        else
                        {
                            resolutionWidth = -intersection.size.width;
                        }
                        p.desiredPosition = ccp(p.desiredPosition.x , p.desiredPosition.y + resolutionWidth);
                    }
                }
                
            }
        }
    }
    //After dealing with any relevant collisions, move the player to new position
    p.position = p.desiredPosition;
}

-(void)checkForBoulders:(Player *)p
{
    //Retrieve set of tiles around player and identify collisions
    NSArray *boulderTiles = [self getSurroundingTiles:p.position forLayer:boulder];
    
    //Loop to check if there is a collision for each new, desired position
    for (NSDictionary *dictionary in boulderTiles)
    {
        //Get the current collision detection box for the player
        CGRect pRectangle = [p collisionDetect];
        
        //Retrieve ID for tile from dictionary
        int gridID = [[dictionary objectForKey:@"tileGridID"] intValue];
        
        if (gridID)
        {
            //If there is a tile in the identified space, create a CGRect to check for collisions
            //If no identified tile, then step is ignored
            CGRect tileRect = CGRectMake([[dictionary objectForKey:@"x"] floatValue], [[dictionary objectForKey:@"y"] floatValue], map3.tileSize.width, map3.tileSize.height);
            //Check for collisions by seeing if the player collision rectangle intersects with any
            //of the tile rectangles
            if (CGRectIntersectsRect(pRectangle, tileRect))
            {
                CGRect intersection = CGRectIntersection(pRectangle, tileRect);
                
                //Use an index to determine the position of the current tile
                int tileIndex = [boulderTiles indexOfObject:dictionary];
                
                if(tileIndex == 0)
                {
                    //Tile is directly below player
                    p.desiredPosition = ccp(p.desiredPosition.x, p.desiredPosition.y + intersection.size.height);
                    //Set the player's vertical velocity back to 0, to prevent falling through the ground
                    p.velocity = ccp(p.velocity.x, 0.0);
                    //State that the player is on the ground
                    p.onGround = YES;
                }
                else if (tileIndex == 1)
                {
                    //Tile is directly above player
                    p.desiredPosition = ccp(p.desiredPosition.x, p.desiredPosition.y - intersection.size.height);
                    p.velocity = ccp(p.velocity.x, 0.0);
                }
                else if (tileIndex == 2)
                {
                    //Tile is to the left of the player
                    p.desiredPosition = ccp(p.desiredPosition.x + intersection.size.width, p.desiredPosition.y);
                    p.boulderHere = YES;
                }
                else if (tileIndex == 3)
                {
                    //Tile is to the right of the player
                    p.desiredPosition = ccp(p.desiredPosition.x - intersection.size.width, p.desiredPosition.y);
                    p.boulderHere = YES;
                }
                else
                {
                    if (intersection.size.width > intersection.size.height)
                    {
                        
                        //Set the player's velocity back to 0, to prevent falling through the ground
                        p.velocity = ccp(p.velocity.x, 0.0);
                        //Tile is diagonal, but resolving collision vertically
                        float resolutionHeight;
                        if (tileIndex > 5)
                        {
                            resolutionHeight = intersection.size.height;
                            //State that the player is on the ground
                            p.onGround = YES;
                        }
                        else
                        {
                            resolutionHeight = -intersection.size.height;
                        }
                        p.desiredPosition = ccp(p.desiredPosition.x, p.desiredPosition.y + resolutionHeight);
                        
                    }
                    else
                    {
                        //Tile is diagonal, but resolving collision as if horizontal
                        float resolutionWidth;
                        if (tileIndex == 6 || tileIndex == 4)
                        {
                            resolutionWidth = intersection.size.width;
                        }
                        else
                        {
                            resolutionWidth = -intersection.size.width;
                        }
                        p.desiredPosition = ccp(p.desiredPosition.x , p.desiredPosition.y + resolutionWidth);
                    }
                }
                
            }
        }
    }
    //After dealing with any relevant collisions, move the player to new position
    p.position = p.desiredPosition;
}

-(void)boulders
{
    //Get the current collision detection box for the player
    CGRect pRectangle = [player collisionDetect];
    
    //Create a collision detection box around the boulders
    
}

-(void)endLevel
{
    //Get the current collision detection box for the player
    CGRect pRectangle = [player collisionDetect];
    
	//Create a collision detection box for the end of the level
    CGRect eRectangle = CGRectMake(986, 170, 34, 68);
    
    //Check if rectangles intersect
	if (CGRectIntersectsRect(eRectangle, pRectangle))
    {
        //Increase score by 5
        player.score = player.score + 5;
		//Replace current scene with next scene
        [[CCDirector sharedDirector] replaceScene:[Level3 scene3]];
    }
}

-(void)scoreAndTime:(ccTime)dt
{
    //Increase time
    player.time++;
    //Change time to seconds rather than loops (assuming 20fps)
    player.timeSeconds = player.time/20;
    
    //Change the score label to match the current score
    [self.scoreLabel setString: [NSString stringWithFormat:@"Score: %i", player.score]];
    //Change the time label to match the current time
    [self.timeLabel setString: [NSString stringWithFormat:@"Time: %i", player.timeSeconds]];
}

-(void)leftButtonPressed:(id)sender
{
    //Set boolean values
    player.moveRight = NO;
    player.moveLeft = YES;
    player.jumpUp = NO;
    player.jumpToRight = NO;
    player.jumpToLeft = NO;
    player.faceRight = NO;
    player.faceLeft = YES;
    
    //Change the player sprite to the correct direction and with or without pickaxe
    if (player.havePickaxe)
    {
        if (player.faceRight)
        {
            
        }
        else if (player.faceLeft)
        {
            [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-left-pickaxe.png"]];
        }
    }
    else if (!player.havePickaxe)
    {
        if (player.faceRight)
        {
            
        }
        else if (player.faceLeft)
        {
            [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-left.png"]];
        }
    }
}

-(void)rightButtonPressed:(id)sender
{
    //Set boolean values
    player.moveRight = YES;
    player.moveLeft = NO;
    player.jumpUp = NO;
    player.jumpToRight = NO;
    player.jumpToLeft = NO;
    player.faceRight = YES;
    player.faceLeft = NO;
    
    //Change the player sprite to the correct direction and with or without pickaxe
    if (player.havePickaxe)
    {
        if (player.faceRight)
        {
            [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-right-pickaxe.png"]];
        }
        else if (player.faceLeft)
        {
            
        }
    }
    else if (!player.havePickaxe)
    {
        if (player.faceRight)
        {
            [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-right.png"]];
        }
        else if (player.faceLeft)
        {
            
        }
    }
}

-(void)jumpButtonPressed:(id)sender
{
    //Set boolean values
    player.moveRight = NO;
    player.moveLeft = NO;
    player.jumpUp = YES;
    player.jumpToRight = NO;
    player.jumpToLeft = NO;
    
}

-(void)jumpLeftButtonPressed:(id)sender
{
    //Set boolean values
    player.moveRight = NO;
    player.moveLeft = NO;
    player.jumpUp = NO;
    player.jumpToRight = NO;
    player.jumpToLeft = YES;
    player.faceRight = NO;
    player.faceLeft = YES;
    
    //Change the player sprite to the correct direction and with or without pickaxe
    if (player.havePickaxe)
    {
        if (player.faceRight)
        {
            
        }
        else if (player.faceLeft)
        {
            [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-left-pickaxe.png"]];
        }
    }
    else if (!player.havePickaxe)
    {
        if (player.faceRight)
        {
            
        }
        else if (player.faceLeft)
        {
            [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-left.png"]];
        }
    }
}

-(void)jumpRightButtonPressed:(id)sender
{
    //Set boolean values
    player.moveRight = NO;
    player.moveLeft = NO;
    player.jumpUp = NO;
    player.jumpToRight = YES;
    player.jumpToLeft = NO;
    player.faceRight = YES;
    player.faceLeft = NO;
    
    //Change the player sprite to the correct direction and with or without pickaxe
    if (player.havePickaxe)
    {
        if (player.faceRight)
        {
            [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-right-pickaxe.png"]];
        }
        else if (player.faceLeft)
        {
            
        }
    }
    else if (!player.havePickaxe)
    {
        if (player.faceRight)
        {
            [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-right.png"]];
        }
        else if (player.faceLeft)
        {
            
        }
    }
}

-(void)actionButtonPressed:(id)sender
{
    //Set boolean values dependant on having pickaxe selected
    if(player.havePickaxe)
    {
        player.moveRight = NO;
        player.moveLeft = NO;
        player.jumpUp = NO;
        player.jumpToRight = NO;
        player.jumpToLeft = NO;
        player.smash = YES;
    }
    //If player does not have the pickaxe selected
    else
    {
        player.moveRight = NO;
        player.moveLeft = NO;
        player.jumpUp = NO;
        player.jumpToRight = NO;
        player.jumpToLeft = NO;
        player.smash = NO;
    }
}

-(void)pickaxeButtonPressed:(id)sender
{
    //Set boolean value
    player.havePickaxe = YES;
    //Change player sprite to include pickaxe
    if (player.faceLeft)
    {
        [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-left-pickaxe.png"]];
    }
    else if (player.faceRight)
    {
        [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-right-pickaxe.png"]];
    }
}

-(void)emptyButtonPressed:(id)sender
{
    //Set boolean value
    player.havePickaxe = NO;
    
    //Change player sprite to remove pickaxe
    if (player.faceLeft)
    {
        [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-left.png"]];
    }
    else if (player.faceRight)
    {
        [player setTexture:[[CCTextureCache sharedTextureCache] addImage:@"player-right.png"]];
    }
}

@end
